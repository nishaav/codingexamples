//package
//import
//class creation
package cg;
import com.Learner;
import java.util.Scanner;
public class Dummy
{
	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		// working with package
			Learner learner=new Learner();
			learner.show();
			// taking user input for addition
			Scanner scanner=new Scanner(System.in);
			System.out.println("Enter two numbers : ");
			int num1=scanner.nextInt();
			int num2=scanner.nextInt();
			int result=num1+num2;
			System.out.println("The output is "+result);
			//closing scanner instance
			scanner.close();
	}
}
