package cg;

public class VarEx {

	//static to static 
	// without local variable
	// with local variable
	static int a=10;
	int b=20;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// case 1 : without a local variable
		System.out.println(a);
		// case 1 : with a local variable
		int a=20;
		System.out.println(a);
		System.out.println(VarEx.a);
		VarEx v=new VarEx();
		//possibility 2
		System.out.println(v.b);
		int b=20;
		System.out.println(b);
		
		
	}

	
}
class Sample
{
	int a=10;
	static int b=30;
	void show()
	{
		//possibility 3
		System.out.println(a);
		int a=10;
		System.out.println(a);
		System.out.println(this.a);
		//possibility 4
		System.out.println(b);
		int b=40;
		System.out.println(b);
		System.out.println(Sample.b);
		
	}
}