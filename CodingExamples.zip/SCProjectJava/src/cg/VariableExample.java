package cg;

public class VariableExample {

	
	int a=20;
	static int b=10;
	public static void main(String[] args) {
		// TODO Auto-generated method stub

//		
//		int b=30;
//	
//		System.out.println(b);//10
//		System.out.println(VariableExample.b);
//		System.out.println(Laptop.b);//40
//		Laptop laptop=new Laptop();
//		System.out.println(laptop.a);//50
//		VariableExample v=new VariableExample();
//		System.out.println(v.a);//20
//		
		Target t=new Target();
		t.show();
		
	}

}
class Laptop
{
	int a=50;
	static int b=40;
}

class Target
{
	int a=10;
	
	void show()
	{
		int a=20;
		System.out.println(a);
		System.out.println(this.a);
		//this is a keyword which works as a object for the current class.
	}
}