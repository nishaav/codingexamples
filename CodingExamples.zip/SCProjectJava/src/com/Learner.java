package com;

public class Learner {

	public void show()
	{
		System.out.println(" Hello User We are working with java package examples");
	}
}
