package com;


import java.util.Scanner;
// java.lang-- automatically added in every java project
// System
// String
// etc
// import-keyword which is used to add the predefined classes in our programs.
// Scanner - used for user-interaction
public class Main
{
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// creating the object
		// non-static to static boundary
		Demo demo=new Demo();
		//classname referenceVariable=new classname();
		demo.show();
		// if we have to call a non-static component inside a static boundary,
		//then you need to create an object
		
		//if we have to call a static component inside a static boundary
		// then no need of object
	}
	
}

class Demo//user-defined class
{
	void show()//non-static user-defined method
	{
		System.out.println("Hello world");
	}
	
	static void display()
	{
		System.out.println("Call static method of Demo");
	}
	
}


