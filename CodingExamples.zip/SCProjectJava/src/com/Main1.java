package com;



public class Main1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
// call show() : static to static
		
		show();
		Demo1.detect();//class as a reference
		//int a;
		Main1 main=new Main1();
		// constructor : Main1()
		main.display();
		Demo1 demo=new Demo1();
		demo.disp();
		
	}
	
	void display()
	{
		System.out.println("Hello world");
		
		dummy();
	}
	
	void dummy()
	{
		System.out.println("Hello Dummy");
		//sample of demo1 inside dummy of main1
		Demo1 demo=new Demo1();
		demo.sample();
	
		//static to non-static 
		
		show();
		
		//static to non-static another class
		Demo1.detect();
	}
	
	static void show()
	{
		System.out.println("Hello User");
	}
}

class Demo1
{
	void disp()
	{
		System.out.println("Hello world, you are in demo1 class");
	}

	void sample() {
		System.out.println("Working with sample");
	}
	
	static void detect()
	{
		System.out.println("Hello User, you are in demo1 class");
	}
}
