package com;

import java.util.Scanner;
public class Main2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		Scanner scanner=new Scanner(System.in);

		System.out.println("Take a fullname : ");
		
		String fullname=scanner.nextLine();
		System.out.println("The name is "+fullname);
		
	System.out.println("Enter a value : ");
		
		int num1=scanner.nextInt();
		System.out.println("The value provided by user is "+num1);
	// + concatenation operator
		// joining multiple strings together
		
		System.out.println("Enter a float value : ");
		
		float num2=scanner.nextFloat();
		
		
		System.out.println("Enter a double value : ");
		
		double num3=scanner.nextDouble();
	
		System.out.println("Enter a String value : ");
		
		String name=scanner.next();
	
		System.out.println(num2+" "+num3+" "+name);
	}

}
/*
 * Scanner
 * 
 * nextInt() : read integer values/initialize int variable
 * next() : read a word (multiple character)/initialize a string
 * nextLong() : read long value/initialize long variable
 * nextFloat() : initialize float variable
 * nextDouble() : initialize double variable
 * nextLine() : read a sentence / (multiple words)/initialize a string
 * 
 * These all are non-static methods
 * need  to create object
 *
 * 
 * 
 * 
 * 
 *  Method calling :
 *  
 *  SAME CLASS
 *  static to static : no object(direct calling)
 *  non-static to static  : needs object
 *  non-static to non-static : no object (direct calling)
 *  static to non-static : no object (direct calling)
 *  
 * 
 * 	DIFFERENT CLASS
 *  static to static : Class as a reference
 *  non-static to static  : needs object
 *  non-static to non-static : needs object
 *  static to non-static : Class as a reference
 *  
 */
