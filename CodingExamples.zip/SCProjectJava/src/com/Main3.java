package com;

public class Main3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

//		int a=10,b=-67,c=100;
//		
//		int result=(a++)+(--b)+(c)+(--c)+(++b)+(--a);
//		System.out.println(result);
//		System.out.println(a+" "+b+" "+c);
//		
//		
		
		Learner learner=new Learner();
		learner.show();
		
	}

}


//Operators :the predefined symbols that will be used to manipulate the operands and 
// work with expressions and conditions
/*
 * Assignment operator  : =
 * Arithmetic Operator  : +,-,/,*,%(modulus)
 *        / : quotient    % : reminder
 *        
 * Arithmetic Assignment Operator : +=, -=,/=, *=, %=        
 *  int a=10;
 *  a+=2;    
 * 
 * unary operator  : single operand : ++,--
 * 
 * 
 * pre / post
 * pre-increment : ++a;
 * post-increment : a++;
 * 
 * 
 */


//